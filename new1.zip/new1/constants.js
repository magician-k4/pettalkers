export const ICONS = {
    hospital: require('./assets/hospital_marker.png'), // 🏥 병원 마커 이미지
  };